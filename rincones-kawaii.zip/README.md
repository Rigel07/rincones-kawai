# Rincones Kawaii (Forge 1.20.1)

Cuatro estructuras con funcion real, cada una con su mob cute:

| Estructura | Mob | Funcion |
|---|---|---|
| Panaderia de las Nubes | Pancito | Tienda con comerciante, cocina, despensa y sotano con botin |
| Observatorio Estelar | Lunita | Mesa de encantamientos con 15 estanterias, telescopio que localiza estructuras, Polvo Estelar |
| Aguas Termales de Mochi | Mochi | Piscina que cura (Piedra Termal), camas, sauna y Mochi Dulce |
| Invernadero de los Brotitos | Brotito | Granja con riego en la que los Brotitos hacen crecer los cultivos |

Compilar: `gradle build` (Java 17, Gradle 8.1.1). El .jar queda en `build/libs/`.
