package com.rinconeskawaii;

import com.rinconeskawaii.registry.ModBlocks;
import com.rinconeskawaii.registry.ModEntities;
import com.rinconeskawaii.registry.ModItems;
import com.rinconeskawaii.registry.ModTabs;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(RinconesKawaii.MODID)
public class RinconesKawaii {
    public static final String MODID = "rinconeskawaii";

    public RinconesKawaii() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModBlocks.BLOCKS.register(bus);
        ModItems.ITEMS.register(bus);
        ModEntities.ENTITIES.register(bus);
        ModTabs.TABS.register(bus);
    }
}
