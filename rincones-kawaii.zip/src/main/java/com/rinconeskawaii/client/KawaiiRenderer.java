package com.rinconeskawaii.client;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Mob;

public class KawaiiRenderer<T extends Mob> extends MobRenderer<T, KawaiiModel<T>> {
    private final ResourceLocation texture;
    private final float scale;

    public KawaiiRenderer(EntityRendererProvider.Context context, KawaiiModel<T> model,
                          float shadowRadius, float scale, ResourceLocation texture) {
        super(context, model, shadowRadius);
        this.texture = texture;
        this.scale = scale;
    }

    @Override
    public ResourceLocation getTextureLocation(T entity) {
        return this.texture;
    }

    @Override
    protected void scale(T entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(this.scale, this.scale, this.scale);
    }
}
