package com.rinconeskawaii.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.rinconeskawaii.RinconesKawaii;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;

/**
 * Un unico modelo "chibi" con cuatro variantes (panecillo, conejita lunar,
 * capibara y brotecito). Todas comparten las mismas partes para poder
 * reutilizar la animacion.
 */
public class KawaiiModel<T extends Entity> extends EntityModel<T> {

    public enum Kind { BUN, MOON, CAPY, SPROUT }

    public static final ModelLayerLocation BUN_LAYER = layer("pancito");
    public static final ModelLayerLocation MOON_LAYER = layer("lunita");
    public static final ModelLayerLocation CAPY_LAYER = layer("mochi");
    public static final ModelLayerLocation SPROUT_LAYER = layer("brotito");

    private static ModelLayerLocation layer(String name) {
        return new ModelLayerLocation(new ResourceLocation(RinconesKawaii.MODID, name), "main");
    }

    private final ModelPart root;
    private final ModelPart head;
    private final ModelPart earL;
    private final ModelPart earR;
    private final ModelPart armL;
    private final ModelPart armR;
    private final ModelPart legL;
    private final ModelPart legR;
    private final ModelPart wingL;
    private final ModelPart wingR;
    private final Kind kind;

    public KawaiiModel(ModelPart root, Kind kind) {
        this.root = root;
        this.kind = kind;
        this.head = root.getChild("head");
        this.earL = this.head.getChild("ear_l");
        this.earR = this.head.getChild("ear_r");
        this.armL = root.getChild("arm_l");
        this.armR = root.getChild("arm_r");
        this.legL = root.getChild("leg_l");
        this.legR = root.getChild("leg_r");
        this.wingL = root.getChild("wing_l");
        this.wingR = root.getChild("wing_r");
    }

    // ------------------------------------------------------------------
    // Mallas
    // ------------------------------------------------------------------

    private static PartDefinition empty(PartDefinition parent, String name) {
        return parent.addOrReplaceChild(name, CubeListBuilder.create(), PartPose.ZERO);
    }

    /** Pancito: panecillo con gorro de panadero. */
    public static LayerDefinition createBun() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition r = mesh.getRoot();

        PartDefinition head = r.addOrReplaceChild("head",
                CubeListBuilder.create().texOffs(0, 0).addBox(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F),
                PartPose.offset(0.0F, 15.0F, 0.0F));
        head.addOrReplaceChild("topper",
                CubeListBuilder.create().texOffs(32, 0).addBox(-3.0F, -13.0F, -3.0F, 6.0F, 5.0F, 6.0F),
                PartPose.ZERO);
        empty(head, "ear_l");
        empty(head, "ear_r");

        r.addOrReplaceChild("body",
                CubeListBuilder.create().texOffs(0, 16).addBox(-3.0F, 0.0F, -2.0F, 6.0F, 6.0F, 4.0F),
                PartPose.offset(0.0F, 15.0F, 0.0F));
        r.addOrReplaceChild("arm_r",
                CubeListBuilder.create().texOffs(24, 16).addBox(-1.0F, -0.5F, -1.0F, 2.0F, 5.0F, 2.0F),
                PartPose.offset(-4.0F, 15.5F, 0.0F));
        r.addOrReplaceChild("arm_l",
                CubeListBuilder.create().texOffs(24, 16).mirror().addBox(-1.0F, -0.5F, -1.0F, 2.0F, 5.0F, 2.0F),
                PartPose.offset(4.0F, 15.5F, 0.0F));
        r.addOrReplaceChild("leg_r",
                CubeListBuilder.create().texOffs(40, 16).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 3.0F, 2.0F),
                PartPose.offset(-1.5F, 21.0F, 0.0F));
        r.addOrReplaceChild("leg_l",
                CubeListBuilder.create().texOffs(40, 16).mirror().addBox(-1.0F, 0.0F, -1.0F, 2.0F, 3.0F, 2.0F),
                PartPose.offset(1.5F, 21.0F, 0.0F));
        empty(r, "wing_l");
        empty(r, "wing_r");
        return LayerDefinition.create(mesh, 64, 64);
    }

    /** Lunita: conejita estelar con orejas largas y alitas. */
    public static LayerDefinition createMoon() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition r = mesh.getRoot();

        PartDefinition head = r.addOrReplaceChild("head",
                CubeListBuilder.create().texOffs(0, 0).addBox(-3.5F, -7.0F, -3.5F, 7.0F, 7.0F, 7.0F),
                PartPose.offset(0.0F, 14.0F, 0.0F));
        empty(head, "topper");
        head.addOrReplaceChild("ear_r",
                CubeListBuilder.create().texOffs(32, 0).addBox(-1.0F, -7.0F, -0.5F, 2.0F, 7.0F, 1.0F),
                PartPose.offsetAndRotation(-2.0F, -6.5F, 0.0F, 0.0F, 0.0F, 0.15F));
        head.addOrReplaceChild("ear_l",
                CubeListBuilder.create().texOffs(32, 0).addBox(-1.0F, -7.0F, -0.5F, 2.0F, 7.0F, 1.0F),
                PartPose.offsetAndRotation(2.0F, -6.5F, 0.0F, 0.0F, 0.0F, -0.15F));

        r.addOrReplaceChild("body",
                CubeListBuilder.create().texOffs(0, 14).addBox(-2.5F, 0.0F, -2.0F, 5.0F, 5.0F, 4.0F),
                PartPose.offset(0.0F, 14.0F, 0.0F));
        r.addOrReplaceChild("arm_r",
                CubeListBuilder.create().texOffs(24, 14).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 4.0F, 2.0F),
                PartPose.offset(-3.5F, 14.5F, 0.0F));
        r.addOrReplaceChild("arm_l",
                CubeListBuilder.create().texOffs(24, 14).mirror().addBox(-1.0F, 0.0F, -1.0F, 2.0F, 4.0F, 2.0F),
                PartPose.offset(3.5F, 14.5F, 0.0F));
        r.addOrReplaceChild("leg_r",
                CubeListBuilder.create().texOffs(40, 14).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 3.0F, 2.0F),
                PartPose.offset(-1.5F, 19.0F, 0.0F));
        r.addOrReplaceChild("leg_l",
                CubeListBuilder.create().texOffs(40, 14).mirror().addBox(-1.0F, 0.0F, -1.0F, 2.0F, 3.0F, 2.0F),
                PartPose.offset(1.5F, 19.0F, 0.0F));
        r.addOrReplaceChild("wing_r",
                CubeListBuilder.create().texOffs(0, 28).addBox(-5.0F, -2.5F, 0.0F, 5.0F, 5.0F, 1.0F),
                PartPose.offsetAndRotation(-1.5F, 15.5F, 2.2F, 0.0F, -0.6F, 0.0F));
        r.addOrReplaceChild("wing_l",
                CubeListBuilder.create().texOffs(0, 28).addBox(0.0F, -2.5F, 0.0F, 5.0F, 5.0F, 1.0F),
                PartPose.offsetAndRotation(1.5F, 15.5F, 2.2F, 0.0F, 0.6F, 0.0F));
        // colita de algodon
        r.addOrReplaceChild("tail",
                CubeListBuilder.create().texOffs(20, 28).addBox(-1.5F, -1.5F, 0.0F, 3.0F, 3.0F, 2.0F),
                PartPose.offset(0.0F, 17.5F, 2.0F));
        return LayerDefinition.create(mesh, 64, 64);
    }

    /** Mochi: capibara con un yuzu en la cabeza. */
    public static LayerDefinition createCapy() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition r = mesh.getRoot();

        PartDefinition head = r.addOrReplaceChild("head",
                CubeListBuilder.create()
                        .texOffs(0, 18).addBox(-3.0F, -2.5F, -5.0F, 6.0F, 5.0F, 5.0F)
                        .texOffs(24, 18).addBox(-2.0F, 0.0F, -7.0F, 4.0F, 3.0F, 2.0F),
                PartPose.offset(0.0F, 16.0F, -5.0F));
        head.addOrReplaceChild("topper",
                CubeListBuilder.create().texOffs(40, 18).addBox(-1.5F, -4.5F, -3.5F, 3.0F, 2.0F, 3.0F),
                PartPose.ZERO);
        head.addOrReplaceChild("ear_r",
                CubeListBuilder.create().texOffs(24, 24).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F),
                PartPose.offset(-2.6F, -2.3F, -1.5F));
        head.addOrReplaceChild("ear_l",
                CubeListBuilder.create().texOffs(24, 24).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F),
                PartPose.offset(2.6F, -2.3F, -1.5F));

        r.addOrReplaceChild("body",
                CubeListBuilder.create().texOffs(0, 0).addBox(-4.0F, -3.0F, -5.0F, 8.0F, 6.0F, 10.0F),
                PartPose.offset(0.0F, 17.0F, 0.0F));
        r.addOrReplaceChild("arm_r",
                CubeListBuilder.create().texOffs(0, 30).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 4.0F, 2.0F),
                PartPose.offset(-2.5F, 20.0F, -3.5F));
        r.addOrReplaceChild("arm_l",
                CubeListBuilder.create().texOffs(0, 30).mirror().addBox(-1.0F, 0.0F, -1.0F, 2.0F, 4.0F, 2.0F),
                PartPose.offset(2.5F, 20.0F, -3.5F));
        r.addOrReplaceChild("leg_r",
                CubeListBuilder.create().texOffs(0, 30).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 4.0F, 2.0F),
                PartPose.offset(-2.5F, 20.0F, 3.5F));
        r.addOrReplaceChild("leg_l",
                CubeListBuilder.create().texOffs(0, 30).mirror().addBox(-1.0F, 0.0F, -1.0F, 2.0F, 4.0F, 2.0F),
                PartPose.offset(2.5F, 20.0F, 3.5F));
        empty(r, "wing_l");
        empty(r, "wing_r");
        return LayerDefinition.create(mesh, 64, 64);
    }

    /** Brotito: criatura verde con un brote de dos hojas. */
    public static LayerDefinition createSprout() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition r = mesh.getRoot();

        PartDefinition head = r.addOrReplaceChild("head",
                CubeListBuilder.create().texOffs(0, 0).addBox(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F),
                PartPose.offset(0.0F, 16.0F, 0.0F));
        head.addOrReplaceChild("topper",
                CubeListBuilder.create().texOffs(32, 0).addBox(-0.5F, -4.0F, -0.5F, 1.0F, 4.0F, 1.0F),
                PartPose.offset(0.0F, -8.0F, 0.0F));
        head.addOrReplaceChild("ear_r",
                CubeListBuilder.create().texOffs(40, 0).addBox(-5.0F, -0.5F, -1.5F, 5.0F, 1.0F, 3.0F),
                PartPose.offsetAndRotation(0.0F, -11.5F, 0.0F, 0.0F, 0.0F, 0.35F));
        head.addOrReplaceChild("ear_l",
                CubeListBuilder.create().texOffs(40, 0).addBox(0.0F, -0.5F, -1.5F, 5.0F, 1.0F, 3.0F),
                PartPose.offsetAndRotation(0.0F, -11.5F, 0.0F, 0.0F, 0.0F, -0.35F));

        r.addOrReplaceChild("body",
                CubeListBuilder.create().texOffs(0, 16).addBox(-3.0F, 0.0F, -2.0F, 6.0F, 5.0F, 4.0F),
                PartPose.offset(0.0F, 16.0F, 0.0F));
        r.addOrReplaceChild("arm_r",
                CubeListBuilder.create().texOffs(24, 16).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 4.0F, 2.0F),
                PartPose.offset(-4.0F, 16.5F, 0.0F));
        r.addOrReplaceChild("arm_l",
                CubeListBuilder.create().texOffs(24, 16).mirror().addBox(-1.0F, 0.0F, -1.0F, 2.0F, 4.0F, 2.0F),
                PartPose.offset(4.0F, 16.5F, 0.0F));
        r.addOrReplaceChild("leg_r",
                CubeListBuilder.create().texOffs(40, 16).addBox(-1.0F, 0.0F, -1.5F, 2.0F, 3.0F, 3.0F),
                PartPose.offset(-1.5F, 21.0F, 0.0F));
        r.addOrReplaceChild("leg_l",
                CubeListBuilder.create().texOffs(40, 16).mirror().addBox(-1.0F, 0.0F, -1.5F, 2.0F, 3.0F, 3.0F),
                PartPose.offset(1.5F, 21.0F, 0.0F));
        empty(r, "wing_l");
        empty(r, "wing_r");
        return LayerDefinition.create(mesh, 64, 64);
    }

    // ------------------------------------------------------------------
    // Animacion
    // ------------------------------------------------------------------

    @Override
    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                          float netHeadYaw, float headPitch) {
        this.head.yRot = netHeadYaw * ((float) Math.PI / 180F);
        this.head.xRot = headPitch * ((float) Math.PI / 180F);

        float swing = Mth.cos(limbSwing * 0.6662F) * 1.2F * limbSwingAmount;
        float sway = Mth.sin(ageInTicks * 0.09F);

        switch (this.kind) {
            case CAPY -> {
                // cuadrupedo: patas en diagonal
                this.armL.xRot = swing;
                this.legR.xRot = swing;
                this.armR.xRot = -swing;
                this.legL.xRot = -swing;
            }
            case MOON -> {
                // flotando: brazos y patitas colgando con un vaiven suave
                this.armL.xRot = 0.0F;
                this.armR.xRot = 0.0F;
                this.armL.zRot = -0.25F - sway * 0.12F;
                this.armR.zRot = 0.25F + sway * 0.12F;
                this.legL.xRot = 0.2F + sway * 0.1F;
                this.legR.xRot = 0.2F - sway * 0.1F;
                this.wingL.yRot = 0.6F + Mth.sin(ageInTicks * 0.7F) * 0.5F;
                this.wingR.yRot = -0.6F - Mth.sin(ageInTicks * 0.7F) * 0.5F;
                this.earL.zRot = -0.15F - sway * 0.08F;
                this.earR.zRot = 0.15F + sway * 0.08F;
            }
            case SPROUT -> {
                this.legL.xRot = swing;
                this.legR.xRot = -swing;
                this.armL.xRot = -swing;
                this.armR.xRot = swing;
                this.earL.zRot = -0.35F - sway * 0.15F;
                this.earR.zRot = 0.35F + sway * 0.15F;
            }
            default -> {
                this.legL.xRot = swing;
                this.legR.xRot = -swing;
                this.armL.xRot = -swing;
                this.armR.xRot = swing;
                this.armL.zRot = -0.05F - sway * 0.05F;
                this.armR.zRot = 0.05F + sway * 0.05F;
            }
        }
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay,
                               float red, float green, float blue, float alpha) {
        this.root.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}
