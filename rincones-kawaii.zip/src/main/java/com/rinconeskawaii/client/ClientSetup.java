package com.rinconeskawaii.client;

import com.rinconeskawaii.RinconesKawaii;
import com.rinconeskawaii.entity.BrotitoEntity;
import com.rinconeskawaii.entity.LunitaEntity;
import com.rinconeskawaii.entity.MochiEntity;
import com.rinconeskawaii.entity.PancitoEntity;
import com.rinconeskawaii.registry.ModEntities;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = RinconesKawaii.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientSetup {

    private static ResourceLocation tex(String name) {
        return new ResourceLocation(RinconesKawaii.MODID, "textures/entity/" + name + ".png");
    }

    @SubscribeEvent
    public static void registerLayers(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(KawaiiModel.BUN_LAYER, KawaiiModel::createBun);
        event.registerLayerDefinition(KawaiiModel.MOON_LAYER, KawaiiModel::createMoon);
        event.registerLayerDefinition(KawaiiModel.CAPY_LAYER, KawaiiModel::createCapy);
        event.registerLayerDefinition(KawaiiModel.SPROUT_LAYER, KawaiiModel::createSprout);
    }

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.PANCITO.get(),
                ctx -> new KawaiiRenderer<PancitoEntity>(ctx,
                        new KawaiiModel<PancitoEntity>(ctx.bakeLayer(KawaiiModel.BUN_LAYER), KawaiiModel.Kind.BUN),
                        0.4F, 0.85F, tex("pancito")));
        event.registerEntityRenderer(ModEntities.LUNITA.get(),
                ctx -> new KawaiiRenderer<LunitaEntity>(ctx,
                        new KawaiiModel<LunitaEntity>(ctx.bakeLayer(KawaiiModel.MOON_LAYER), KawaiiModel.Kind.MOON),
                        0.25F, 0.65F, tex("lunita")));
        event.registerEntityRenderer(ModEntities.MOCHI.get(),
                ctx -> new KawaiiRenderer<MochiEntity>(ctx,
                        new KawaiiModel<MochiEntity>(ctx.bakeLayer(KawaiiModel.CAPY_LAYER), KawaiiModel.Kind.CAPY),
                        0.5F, 1.0F, tex("mochi")));
        event.registerEntityRenderer(ModEntities.BROTITO.get(),
                ctx -> new KawaiiRenderer<BrotitoEntity>(ctx,
                        new KawaiiModel<BrotitoEntity>(ctx.bakeLayer(KawaiiModel.SPROUT_LAYER), KawaiiModel.Kind.SPROUT),
                        0.3F, 0.7F, tex("brotito")));
    }
}
