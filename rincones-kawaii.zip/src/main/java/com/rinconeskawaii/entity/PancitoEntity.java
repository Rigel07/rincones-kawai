package com.rinconeskawaii.entity;

import com.rinconeskawaii.entity.ai.StayNearHomeGoal;
import com.rinconeskawaii.registry.ModItems;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.InteractGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.PanicGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.TradeWithPlayerGoal;
import net.minecraft.world.entity.ai.goal.LookAtTradingPlayerGoal;
import net.minecraft.world.entity.npc.WanderingTrader;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.trading.MerchantOffer;
import net.minecraft.world.item.trading.MerchantOffers;
import net.minecraft.world.level.Level;

/**
 * Pancito, el panadero de la Panaderia de las Nubes. Comercia con los jugadores
 * y se queda siempre cerca de su tienda.
 */
public class PancitoEntity extends WanderingTrader {

    public PancitoEntity(EntityType<? extends WanderingTrader> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.5D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new PanicGoal(this, 1.2D));
        this.goalSelector.addGoal(1, new TradeWithPlayerGoal(this));
        this.goalSelector.addGoal(1, new LookAtTradingPlayerGoal(this));
        this.goalSelector.addGoal(2, new StayNearHomeGoal(this, 5.0D, 0.6D));
        this.goalSelector.addGoal(3, new WaterAvoidingRandomStrollGoal(this, 0.5D));
        this.goalSelector.addGoal(4, new InteractGoal(this, Player.class, 3.0F, 1.0F));
        this.goalSelector.addGoal(5, new LookAtPlayerGoal(this, Mob.class, 8.0F));
        this.goalSelector.addGoal(6, new RandomLookAroundGoal(this));
    }

    @Override
    protected void updateTrades() {
        MerchantOffers offers = this.getOffers();
        // Pancito vende dulces...
        offers.add(new MerchantOffer(new ItemStack(Items.EMERALD, 1),
                new ItemStack(ModItems.GALLETA.get(), 6), 16, 4, 0.05F));
        offers.add(new MerchantOffer(new ItemStack(Items.WHEAT, 6), new ItemStack(Items.SUGAR, 2),
                new ItemStack(ModItems.PASTEL.get(), 2), 12, 6, 0.05F));
        offers.add(new MerchantOffer(new ItemStack(Items.EMERALD, 1),
                new ItemStack(Items.CAKE, 1), 6, 5, 0.05F));
        offers.add(new MerchantOffer(new ItemStack(Items.EMERALD, 1),
                new ItemStack(ModItems.BROTE.get(), 4), 12, 3, 0.05F));
        offers.add(new MerchantOffer(new ItemStack(Items.EMERALD, 3),
                new ItemStack(Items.GOLDEN_APPLE, 1), 3, 10, 0.05F));
        // ...y compra lo que se consigue en los otros rincones kawaii
        offers.add(new MerchantOffer(new ItemStack(Items.BREAD, 8),
                new ItemStack(Items.EMERALD, 1), 16, 3, 0.05F));
        offers.add(new MerchantOffer(new ItemStack(ModItems.MOCHI.get(), 2),
                new ItemStack(Items.EMERALD, 1), 16, 4, 0.05F));
        offers.add(new MerchantOffer(new ItemStack(ModItems.POLVO_ESTELAR.get(), 6),
                new ItemStack(Items.DIAMOND, 1), 4, 12, 0.05F));
    }

    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) {
        return false;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.VILLAGER_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.VILLAGER_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.VILLAGER_DEATH;
    }
}
