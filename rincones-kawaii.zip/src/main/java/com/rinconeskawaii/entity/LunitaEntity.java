package com.rinconeskawaii.entity;

import com.rinconeskawaii.entity.ai.StayNearHomeGoal;
import com.rinconeskawaii.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.control.FlyingMoveControl;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.PanicGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomFlyingGoal;
import net.minecraft.world.entity.ai.navigation.FlyingPathNavigation;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Lunita, conejita estelar del Observatorio. Flota, y de noche regala vision
 * nocturna y caida lenta a quien este cerca. Ademas suelta Polvo Estelar.
 */
public class LunitaEntity extends KawaiiMob {
    private int dustTime;

    public LunitaEntity(EntityType<? extends LunitaEntity> type, Level level) {
        super(type, level);
        this.moveControl = new FlyingMoveControl(this, 10, true);
        this.dustTime = 4000 + this.random.nextInt(4000);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 10.0D)
                .add(Attributes.FLYING_SPEED, 0.5D)
                .add(Attributes.MOVEMENT_SPEED, 0.25D);
    }

    @Override
    protected PathNavigation createNavigation(Level level) {
        FlyingPathNavigation navigation = new FlyingPathNavigation(this, level);
        navigation.setCanOpenDoors(false);
        navigation.setCanFloat(true);
        navigation.setCanPassDoors(true);
        return navigation;
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(1, new PanicGoal(this, 1.3D));
        this.goalSelector.addGoal(2, new StayNearHomeGoal(this, 9.0D, 1.0D));
        this.goalSelector.addGoal(3, new WaterAvoidingRandomFlyingGoal(this, 1.0D));
        this.goalSelector.addGoal(4, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(5, new RandomLookAroundGoal(this));
    }

    @Override
    public void aiStep() {
        super.aiStep();
        Level lvl = this.level();
        if (lvl.isClientSide) {
            if (this.random.nextInt(10) == 0) {
                lvl.addParticle(ParticleTypes.END_ROD,
                        this.getRandomX(0.6D), this.getRandomY(), this.getRandomZ(0.6D),
                        0.0D, -0.01D, 0.0D);
            }
            return;
        }
        boolean night = lvl.isNight();
        if (night && this.tickCount % 60 == 0) {
            for (Player player : lvl.getEntitiesOfClass(Player.class, this.getBoundingBox().inflate(10.0D))) {
                player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 400, 0, true, false));
                player.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 200, 0, true, false));
            }
        }
        if (this.dustTime > 0) {
            this.dustTime--;
        } else if (night) {
            this.spawnAtLocation(ModItems.POLVO_ESTELAR.get());
            this.playSound(SoundEvents.AMETHYST_BLOCK_CHIME, 1.0F, 1.4F);
            this.dustTime = 6000 + this.random.nextInt(6000);
        }
    }

    @Override
    public boolean causeFallDamage(float distance, float multiplier, DamageSource source) {
        return false;
    }

    @Override
    protected void checkFallDamage(double y, boolean onGround, BlockState state, BlockPos pos) {
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.ALLAY_AMBIENT_WITHOUT_ITEM;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ALLAY_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ALLAY_DEATH;
    }
}
