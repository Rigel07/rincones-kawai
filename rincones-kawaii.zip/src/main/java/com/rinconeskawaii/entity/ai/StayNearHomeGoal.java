package com.rinconeskawaii.entity.ai;

import java.util.EnumSet;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.phys.Vec3;

/** Hace que el mob vuelva a su estructura si se aleja demasiado. */
public class StayNearHomeGoal extends Goal {
    private final PathfinderMob mob;
    private final double radius;
    private final double speed;

    public StayNearHomeGoal(PathfinderMob mob, double radius, double speed) {
        this.mob = mob;
        this.radius = radius;
        this.speed = speed;
        this.setFlags(EnumSet.of(Flag.MOVE));
    }

    @Override
    public boolean canUse() {
        BlockPos home = Home.get(mob);
        if (home == null) {
            Home.set(mob, mob.blockPosition());
            return false;
        }
        return mob.distanceToSqr(Vec3.atCenterOf(home)) > radius * radius;
    }

    @Override
    public boolean canContinueToUse() {
        return !mob.getNavigation().isDone();
    }

    @Override
    public void start() {
        BlockPos home = Home.get(mob);
        if (home != null) {
            mob.getNavigation().moveTo(home.getX() + 0.5D, home.getY(), home.getZ() + 0.5D, speed);
        }
    }
}
