package com.rinconeskawaii.entity.ai;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.Entity;

/** Guarda en el NBT persistente de la entidad el "hogar" (la estructura donde nacio). */
public final class Home {
    private static final String KEY = "kawaii_home";

    private Home() {
    }

    public static void set(Entity entity, BlockPos pos) {
        entity.getPersistentData().putLong(KEY, pos.asLong());
    }

    public static BlockPos get(Entity entity) {
        CompoundTag tag = entity.getPersistentData();
        return tag.contains(KEY) ? BlockPos.of(tag.getLong(KEY)) : null;
    }
}
