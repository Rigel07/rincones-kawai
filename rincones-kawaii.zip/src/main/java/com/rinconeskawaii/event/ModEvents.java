package com.rinconeskawaii.event;

import com.rinconeskawaii.RinconesKawaii;
import com.rinconeskawaii.entity.BrotitoEntity;
import com.rinconeskawaii.entity.LunitaEntity;
import com.rinconeskawaii.entity.MochiEntity;
import com.rinconeskawaii.entity.PancitoEntity;
import com.rinconeskawaii.registry.ModEntities;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = RinconesKawaii.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ModEvents {

    @SubscribeEvent
    public static void onAttributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.PANCITO.get(), PancitoEntity.createAttributes().build());
        event.put(ModEntities.LUNITA.get(), LunitaEntity.createAttributes().build());
        event.put(ModEntities.MOCHI.get(), MochiEntity.createAttributes().build());
        event.put(ModEntities.BROTITO.get(), BrotitoEntity.createAttributes().build());
    }
}
