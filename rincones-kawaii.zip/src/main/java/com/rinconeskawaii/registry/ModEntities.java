package com.rinconeskawaii.registry;

import com.rinconeskawaii.RinconesKawaii;
import com.rinconeskawaii.entity.BrotitoEntity;
import com.rinconeskawaii.entity.LunitaEntity;
import com.rinconeskawaii.entity.MochiEntity;
import com.rinconeskawaii.entity.PancitoEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, RinconesKawaii.MODID);

    public static final RegistryObject<EntityType<PancitoEntity>> PANCITO = ENTITIES.register("pancito",
            () -> EntityType.Builder.of(PancitoEntity::new, MobCategory.CREATURE)
                    .sized(0.6F, 1.2F).clientTrackingRange(10).build("pancito"));

    public static final RegistryObject<EntityType<LunitaEntity>> LUNITA = ENTITIES.register("lunita",
            () -> EntityType.Builder.of(LunitaEntity::new, MobCategory.CREATURE)
                    .sized(0.5F, 0.8F).clientTrackingRange(10).build("lunita"));

    public static final RegistryObject<EntityType<MochiEntity>> MOCHI = ENTITIES.register("mochi",
            () -> EntityType.Builder.of(MochiEntity::new, MobCategory.CREATURE)
                    .sized(0.9F, 0.8F).clientTrackingRange(10).build("mochi"));

    public static final RegistryObject<EntityType<BrotitoEntity>> BROTITO = ENTITIES.register("brotito",
            () -> EntityType.Builder.of(BrotitoEntity::new, MobCategory.CREATURE)
                    .sized(0.5F, 0.95F).clientTrackingRange(10).build("brotito"));
}
