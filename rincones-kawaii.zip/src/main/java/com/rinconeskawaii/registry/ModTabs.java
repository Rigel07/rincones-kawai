package com.rinconeskawaii.registry;

import com.rinconeskawaii.RinconesKawaii;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public class ModTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, RinconesKawaii.MODID);

    public static final RegistryObject<CreativeModeTab> RINCONES = TABS.register("rincones",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.rinconeskawaii"))
                    .icon(() -> new ItemStack(ModItems.GALLETA.get()))
                    .displayItems((params, output) -> {
                        ModItems.ITEMS.getEntries().forEach(item -> output.accept(item.get()));
                    })
                    .build());
}
