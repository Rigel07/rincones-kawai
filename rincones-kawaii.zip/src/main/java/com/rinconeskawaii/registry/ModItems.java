package com.rinconeskawaii.registry;

import com.rinconeskawaii.RinconesKawaii;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.BoneMealItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, RinconesKawaii.MODID);

    // ---- Comida y materiales ----
    public static final RegistryObject<Item> GALLETA = ITEMS.register("galleta_kawaii",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder()
                    .nutrition(3).saturationMod(0.4F).fast().build())));

    public static final RegistryObject<Item> PASTEL = ITEMS.register("pastel_de_nube",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder()
                    .nutrition(6).saturationMod(0.6F)
                    .effect(() -> new MobEffectInstance(MobEffects.SLOW_FALLING, 600, 0), 1.0F)
                    .build())));

    public static final RegistryObject<Item> MOCHI = ITEMS.register("mochi_dulce",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder()
                    .nutrition(4).saturationMod(0.5F)
                    .effect(() -> new MobEffectInstance(MobEffects.REGENERATION, 100, 0), 1.0F)
                    .build())));

    public static final RegistryObject<Item> POLVO_ESTELAR = ITEMS.register("polvo_estelar",
            () -> new Item(new Item.Properties()));

    // Funciona como harina de huesos: hace crecer cultivos
    public static final RegistryObject<Item> BROTE = ITEMS.register("brote_brillante",
            () -> new BoneMealItem(new Item.Properties()));

    // ---- Items de bloque ----
    public static final RegistryObject<Item> TELESCOPIO = ITEMS.register("telescopio",
            () -> new BlockItem(ModBlocks.TELESCOPIO.get(), new Item.Properties()));

    public static final RegistryObject<Item> PIEDRA_TERMAL = ITEMS.register("piedra_termal",
            () -> new BlockItem(ModBlocks.PIEDRA_TERMAL.get(), new Item.Properties()));

    // ---- Huevos de aparicion ----
    public static final RegistryObject<Item> PANCITO_EGG = ITEMS.register("pancito_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.PANCITO, 0xE9B872, 0xFF9EBB, new Item.Properties()));

    public static final RegistryObject<Item> LUNITA_EGG = ITEMS.register("lunita_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.LUNITA, 0xC9B8F5, 0xFFE27A, new Item.Properties()));

    public static final RegistryObject<Item> MOCHI_EGG = ITEMS.register("mochi_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.MOCHI, 0xB98A62, 0xFFA63D, new Item.Properties()));

    public static final RegistryObject<Item> BROTITO_EGG = ITEMS.register("brotito_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.BROTITO, 0xA8E6A1, 0xFF8FB8, new Item.Properties()));
}
