package com.rinconeskawaii.registry;

import com.rinconeskawaii.RinconesKawaii;
import com.rinconeskawaii.block.PiedraTermalBlock;
import com.rinconeskawaii.block.TelescopioBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, RinconesKawaii.MODID);

    public static final RegistryObject<Block> TELESCOPIO = BLOCKS.register("telescopio",
            () -> new TelescopioBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_PINK)
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .noOcclusion()));

    public static final RegistryObject<Block> PIEDRA_TERMAL = BLOCKS.register("piedra_termal",
            () -> new PiedraTermalBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_PINK)
                    .strength(1.5F, 6.0F)
                    .sound(SoundType.STONE)
                    .lightLevel(state -> 7)));
}
