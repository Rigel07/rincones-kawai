package com.rinconeskawaii.block;

import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.npc.AbstractVillager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import com.rinconeskawaii.entity.KawaiiMob;

/**
 * Piedra termal: calienta el agua que tiene encima. Quien se bane sobre ella
 * se regenera, entra en calor y se limpia de efectos malos.
 */
public class PiedraTermalBlock extends Block {

    public PiedraTermalBlock(Properties properties) {
        super(properties);
    }

    @Override
    public void onPlace(BlockState state, Level level, BlockPos pos, BlockState oldState, boolean moving) {
        if (!level.isClientSide) {
            level.scheduleTick(pos, this, 20);
        }
    }

    // Durante la generacion del mundo no se llama a onPlace, asi que los ticks
    // aleatorios arrancan el ciclo la primera vez que el chunk esta cargado.
    @Override
    public boolean isRandomlyTicking(BlockState state) {
        return true;
    }

    @Override
    public void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        level.scheduleTick(pos, this, 20);
    }

    @Override
    public void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        AABB area = new AABB(pos.getX(), pos.getY() + 1, pos.getZ(), pos.getX() + 1, pos.getY() + 3, pos.getZ() + 1);
        List<LivingEntity> bathers = level.getEntitiesOfClass(LivingEntity.class, area);
        boolean someone = false;
        for (LivingEntity entity : bathers) {
            boolean friendly = entity instanceof Player || entity instanceof Animal
                    || entity instanceof AbstractVillager || entity instanceof KawaiiMob;
            if (!friendly || !entity.isInWater()) {
                continue;
            }
            someone = true;
            entity.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 60, 0, true, true));
            entity.removeEffect(MobEffects.POISON);
            entity.removeEffect(MobEffects.WEAKNESS);
            entity.removeEffect(MobEffects.HUNGER);
            entity.removeEffect(MobEffects.CONFUSION);
            entity.setTicksFrozen(0);
        }
        if (someone) {
            level.sendParticles(ParticleTypes.HEART, pos.getX() + 0.5D, pos.getY() + 2.2D, pos.getZ() + 0.5D,
                    1, 0.3D, 0.1D, 0.3D, 0.0D);
        }
        level.scheduleTick(pos, this, 20);
    }
}
