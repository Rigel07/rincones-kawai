package com.rinconeskawaii.block;

import com.rinconeskawaii.RinconesKawaii;
import com.rinconeskawaii.registry.ModItems;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.TagKey;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Telescopio: al usarlo busca el rincon kawaii mas cercano y te dice hacia donde
 * mirar. De noche, a veces ves una estrella fugaz y consigues Polvo Estelar.
 */
public class TelescopioBlock extends HorizontalDirectionalBlock {
    private static final VoxelShape SHAPE = Block.box(3.0D, 0.0D, 3.0D, 13.0D, 14.0D, 13.0D);
    private static final Map<UUID, Long> COOLDOWN = new HashMap<>();
    private static final String[] STRUCTURES = {"panaderia", "observatorio", "termas", "invernadero"};
    private static final String[] DIRECTIONS = {"n", "ne", "e", "se", "s", "sw", "w", "nw"};
    private static final int SEARCH_RADIUS_CHUNKS = 60;

    public TelescopioBlock(Properties properties) {
        super(properties);
        this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        return this.defaultBlockState().setValue(FACING, context.getHorizontalDirection().getOpposite());
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return SHAPE;
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player,
                                 InteractionHand hand, BlockHitResult hit) {
        if (level.isClientSide) {
            return InteractionResult.SUCCESS;
        }
        ServerLevel serverLevel = (ServerLevel) level;
        long now = level.getGameTime();
        Long last = COOLDOWN.get(player.getUUID());
        if (last != null && now - last < 100L) {
            player.displayClientMessage(Component.translatable("message.rinconeskawaii.telescopio.espera"), true);
            return InteractionResult.CONSUME;
        }
        COOLDOWN.put(player.getUUID(), now);

        String bestName = null;
        double bestDistSqr = Double.MAX_VALUE;
        double bestDx = 0;
        double bestDz = 0;
        for (String name : STRUCTURES) {
            TagKey<Structure> tag = TagKey.create(Registries.STRUCTURE, new ResourceLocation(RinconesKawaii.MODID, name));
            BlockPos found = serverLevel.findNearestMapStructure(tag, pos, SEARCH_RADIUS_CHUNKS, false);
            if (found == null) {
                continue;
            }
            double dx = found.getX() - pos.getX();
            double dz = found.getZ() - pos.getZ();
            double dist = dx * dx + dz * dz;
            if (dist < bestDistSqr) {
                bestDistSqr = dist;
                bestName = name;
                bestDx = dx;
                bestDz = dz;
            }
        }

        if (bestName == null) {
            player.displayClientMessage(Component.translatable("message.rinconeskawaii.telescopio.nada"), false);
        } else {
            double bearing = Math.toDegrees(Math.atan2(bestDx, -bestDz));
            int index = (int) Math.round(((bearing + 360.0D) % 360.0D) / 45.0D) % 8;
            player.displayClientMessage(Component.translatable("message.rinconeskawaii.telescopio.visto",
                    Component.translatable("structure.rinconeskawaii." + bestName),
                    Component.translatable("direction.rinconeskawaii." + DIRECTIONS[index]),
                    (int) Math.sqrt(bestDistSqr)), false);
        }

        if (level.isNight() && level.random.nextFloat() < 0.5F) {
            ItemStack dust = new ItemStack(ModItems.POLVO_ESTELAR.get());
            if (!player.getInventory().add(dust)) {
                player.drop(dust, false);
            }
            player.displayClientMessage(Component.translatable("message.rinconeskawaii.telescopio.estrella"), false);
        }
        return InteractionResult.CONSUME;
    }
}
